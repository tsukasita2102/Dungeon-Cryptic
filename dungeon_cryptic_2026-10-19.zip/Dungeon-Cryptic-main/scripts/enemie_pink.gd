extends CharacterBody2D

@export_group("Movimiento")
@export var velocidad_patrulla: float = 65.0
@export var velocidad_persecucion: float = 110.0
@export var distancia_patrulla: float = 130.0
@export var gravedad: float = 980.0
@export var fuerza_salto: float = -320.0
@export var intervalo_salto: float = 1.8
@export var saltar_patrullando: bool = true

@export_group("Deteccion y combate")
@export var rango_vision: float = 230.0
@export var altura_vision: float = 110.0
@export var distancia_ataque: float = 34.0
@export var altura_ataque: float = 38.0
@export var dano: int = 1
@export var intervalo_ataque: float = 1.3
@export var vida_maxima: int = 3

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var barra: ProgressBar = $HealthBar
@onready var punto_a: Marker2D = $PositionPatrolA
@onready var punto_b: Marker2D = $PositionPatrolB
@onready var colision: CollisionShape2D = $CollisionShape2D

var vida: int = 3
var muerto: bool = false
var atacando: bool = false
var direccion: int = 1
var origen_x: float = 0.0
var objetivo: CharacterBody2D = null
var reloj_salto: float = 0.0
var reloj_ataque: float = 0.0
var indice_ataque: int = 0
var limite_izquierdo: float = 0.0
var limite_derecho: float = 0.0
var direction: Vector2 = Vector2.ZERO


func _ready() -> void:
	vida = vida_maxima
	origen_x = global_position.x

	limite_izquierdo = origen_x - distancia_patrulla
	limite_derecho = origen_x + distancia_patrulla

	if not is_zero_approx(punto_a.position.x - punto_b.position.x):
		limite_izquierdo = min(
			punto_a.global_position.x,
			punto_b.global_position.x
		)
		limite_derecho = max(
			punto_a.global_position.x,
			punto_b.global_position.x
		)

	barra.max_value = vida_maxima
	barra.value = vida
	barra.mouse_filter = Control.MOUSE_FILTER_IGNORE

	_animar(&"idle")


func _physics_process(delta: float) -> void:
	if muerto:
		return

	if not is_on_floor():
		velocity.y += gravedad * delta

	reloj_salto += delta
	reloj_ataque = maxf(0.0, reloj_ataque - delta)

	_buscar_jugador()

	if atacando:
		velocity.x = 0.0
	elif objetivo != null:
		_perseguir()
	else:
		_patrullar()

	move_and_slide()

	if not atacando:
		if not is_on_floor():
			_animar(&"jump")
		elif absf(velocity.x) > 1.0:
			_animar(&"walk")
		else:
			_animar(&"idle")


func _buscar_jugador() -> void:
	objetivo = null

	for nodo in get_tree().get_nodes_in_group("player"):
		if not nodo is CharacterBody2D:
			continue

		if nodo.get("defeated") == true:
			continue

		var dx: float = absf(
			nodo.global_position.x - global_position.x
		)
		var dy: float = absf(
			nodo.global_position.y - global_position.y
		)

		if dx <= rango_vision and dy <= altura_vision:
			objetivo = nodo
			return


func _patrullar() -> void:
	if global_position.x >= limite_derecho:
		direccion = -1

	# Cambiar de direccion al llegar al limite izquierdo
	elif global_position.x <= limite_izquierdo:
		direccion = 1

	# Cambiar la orientacion del enemigo
	_orientar()

	# Caminar sin saltar
	velocity.x = direccion * velocidad_patrulla

	# Mantener al enemigo en el suelo
	# No se llama a la funcion _saltar()


func _perseguir() -> void:
	if not is_instance_valid(objetivo):
		objetivo = null
		return

	var dx: float = (
		objetivo.global_position.x - global_position.x
	)
	var dy: float = (
		objetivo.global_position.y - global_position.y
	)

	if absf(dx) > 4.0:
		direccion = 1 if dx > 0.0 else -1

	_orientar()

	if _esta_en_rango_ataque(objetivo):
		velocity.x = 0.0

		if reloj_ataque <= 0.0:
			_atacar()

		return

	velocity.x = direccion * velocidad_persecucion

	if _puede_saltar() and (
		is_on_wall() or dy < -30.0
	):
		_saltar()


func _puede_saltar() -> bool:
	return (
		is_on_floor()
		and reloj_salto >= intervalo_salto
		and not atacando
	)


func _saltar() -> void:
	velocity.y = fuerza_salto
	reloj_salto = 0.0
	_animar(&"jump")


func _esta_en_rango_ataque(cuerpo: Node2D) -> bool:
	return (
		absf(cuerpo.global_position.x - global_position.x)
		<= distancia_ataque
		and
		absf(cuerpo.global_position.y - global_position.y)
		<= altura_ataque
	)






func _atacar() -> void:
	if muerto or atacando or not is_instance_valid(objetivo):
		return

	if objetivo.defeated:
		return

	atacando = true
	reloj_ataque = intervalo_ataque
	velocity.x = 0.0

	var jugador_atacado: CharacterBody2D = objetivo

	# Elegir el ataque
	var ataque: StringName = &"attack_1"

	if indice_ataque % 2 == 1:
		ataque = &"attack_2"

	indice_ataque += 1

	# Girar hacia el jugador antes de atacar
	if jugador_atacado.global_position.x > global_position.x:
		direccion = 1
	else:
		direccion = -1

	_orientar()

	# Reproducir la animacion
	_animar(ataque)

	# Esperar el momento del golpe
	await get_tree().create_timer(0.3).timeout

	if muerto or not is_inside_tree():
		return

	# Comprobar si el jugador sigue vivo y cerca
	if is_instance_valid(jugador_atacado):
		if not jugador_atacado.defeated:

			# Girar nuevamente si el jugador cambio de lado
			if jugador_atacado.global_position.x > global_position.x:
				direccion = 1
			else:
				direccion = -1

			_orientar()

			if _esta_en_rango_ataque(jugador_atacado):
				jugador_atacado.damage(dano)

	# Esperar a que termine el ataque
	await get_tree().create_timer(0.4).timeout

	if muerto or not is_inside_tree():
		return

	atacando = false
	
func damage(cantidad: int = 1) -> void:
	if muerto:
		return

	vida = maxi(0, vida - cantidad)
	barra.value = vida

	if vida == 0:
		morir()


func morir() -> void:
	if muerto:
		return

	muerto = true
	atacando = false
	objetivo = null

	velocity = Vector2.ZERO

	set_physics_process(false)
	colision.set_deferred("disabled", true)

	_animar(&"death")

	if sprite.sprite_frames.has_animation(&"death"):
		var frames: int = (
			sprite.sprite_frames.get_frame_count(&"death")
		)
		var fps: float = (
			sprite.sprite_frames.get_animation_speed(&"death")
		)

		if fps > 0.0:
			await get_tree().create_timer(
				float(frames) / fps
			).timeout

	if is_inside_tree():
		queue_free()



func _orientar() -> void:
	if is_instance_valid(objetivo):
		# Calcular la direccion hacia el jugador
		direction = (
			objetivo.global_position - global_position
		).normalized()

		# Actualizar la direccion horizontal
		if direction.x > 0:
			direccion = 1
		elif direction.x < 0:
			direccion = -1

	# Girar el sprite hacia el jugador
	sprite.flip_h = direccion < 0


func _animar(nombre: StringName) -> void:
	if not sprite.sprite_frames.has_animation(nombre):
		return

	if sprite.animation != nombre or not sprite.is_playing():
		sprite.play(nombre)
